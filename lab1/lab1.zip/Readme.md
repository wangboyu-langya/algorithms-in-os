Please use gcc version 6.2.0 (GCC) to compile.
