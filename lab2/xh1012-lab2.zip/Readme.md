Please use gcc version 6.2.0 (GCC) with -std=c++11 to compile.
